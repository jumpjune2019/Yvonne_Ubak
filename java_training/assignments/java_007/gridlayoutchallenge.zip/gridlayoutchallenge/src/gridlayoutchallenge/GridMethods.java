package gridlayoutchallenge;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Random;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GridMethods {
	//globals
	JFrame frm;
	JPanel pan;
	JPanel cellPan;
	JPanel centerPan;
	JLabel introLbl;
	JLabel selectedLbl;
	JLabel seatLbl;
	JButton seatBtn;
	
	
	//function to get random rows and columns
	RandFunc setMatrix = (min, max) -> {
		Random r = new Random();
		int rVal;

		rVal = r.nextInt((max-min) + 1) + min;

		return  rVal;
	};
	
	//create swing app
	FrameFunc createFrame = (jfrm, title, jpan, cpan, intro, lbl, cell) ->{
		//outer frame and panel
		jfrm = new JFrame(title);
		jpan = new JPanel();
		BorderLayout blayout = new BorderLayout();
		jpan.setLayout(blayout);
		jfrm.setLocationRelativeTo(null);
		jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//top region
		introLbl = new JLabel(intro);
		introLbl.setHorizontalAlignment(JLabel.CENTER);
		introLbl.setVerticalAlignment(JLabel.CENTER);
		
		//bottom region
		selectedLbl = new JLabel(lbl);
		selectedLbl.setHorizontalAlignment(JLabel.CENTER);
		selectedLbl.setVerticalAlignment(JLabel.CENTER);
		
		//center region
			//center panel
		cpan = new JPanel();
		int row = setMatrix.rcval(2, 5);	//generate rows
		int col = setMatrix.rcval(2, 5);	//generate columns
		System.out.println(row);
		System.out.println(col);
		GridLayout glayout = new GridLayout(row, col);
		cpan.setLayout(glayout);
		//int w = 50 * 2;	//each cell width is 50
		//int h = 50* 2;	//each cell height is 50
		//cpan.setSize(new Dimension(w, h));
			//cell panel
		/*cell = new JPanel();
		BoxLayout bxlayout = new BoxLayout(cell, BoxLayout.Y_AXIS);
		cell.setLayout(bxlayout);
		cell.setSize(new Dimension(50, 50));*/
		
			//cell settings
			char x = 'A';
			int seat = 1;
			for(int r = 0; r < (row * col); r++) {
				if(r == col || r == col*2 || r == col*3 || r == col*4) {
					x++;
					seat =1;
				}
				seatLbl = new JLabel(x + "-" + seat);
				seatBtn = new JButton(x + "-" + seat);
				cpan.add(seatBtn);	
				//cell.add(seatBtn);
				//cpan.add(cell);
				seat++;
			}
		
		//add elements
		jfrm.setSize(new Dimension(500, (row * 50) + 80));
		jfrm.add(jpan);
		jpan.add(introLbl, BorderLayout.NORTH);
		jpan.add(selectedLbl, BorderLayout.SOUTH);
		jpan.add(cpan, BorderLayout.CENTER);
		jfrm.setVisible(true);
		
	};
	
	void invokeApp() {
		createFrame.app(frm, "GridLayout Challenge", pan, centerPan, "Basic Matrix Demo", 
				"No seat selected", cellPan);
	}
	

}
